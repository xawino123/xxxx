# Dökümantasyon
Kategoriler:
* [Kurulum](installation.md)
* [Ayarlar](settings.md)
    * [GENERIC_SUPERUSER_USERNAME](settings.md#generic_superuser_username)
    * [GENERIC_PRIVATEUSER_USERNAME](settings.md#generic_privateuser_username)
* [Çeviri](translation.md)
    * [Çeviri dosyalarının derlenmesi](translation.md#çeviri-dosyalarının-derlenmesi)
    * [Yeni çeviri oluşturulması](translation.md#yeni-çeviri-oluşturulması)
* [Güvenlik](security.md)
    * [Bildirimler](security.md#bildirimler)
* [Javascript](javascript.md)
    * [Dosyaların derlenmesi](javascript.md#dosyaların-derlenmesi)
* [Sunucuya kurulum yapacaklar için notlar](deployment.md)


Diğer:

[Katkıda bulunanların listesi](/CONTRIBUTORS)\
[Sürüm değişiklik bilgileri](/CHANGELOG)\
[Lisans](/LICENSE)
