Contents of the desktop snapshot were taken from ekşi sözlük on July 12, 2020; their rights might be reserved.\
Contents of the desktop snapshot (dark) were taken from ekşi sözlük on Sept 4, 2020: their rights might be reserved.

All screenshots were taken with Mozilla Firefox.
