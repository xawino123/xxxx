`This app serves the Graph API of django-sozluk.
Currently, the API only serves utility calls for the main site and not near to be complete.
So, it is not available for standalone use.`
